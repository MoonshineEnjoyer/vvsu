#pragma once

#include <vector>
#include "scooter.hpp"

struct Statistics
{
    int totalScooters;
    int readyCount;
    int chargeRequiredCount;
    int serviceRequiredCount;
    double readyPercent;
    double averageCharge;
};

Statistics calculateStatistics(const std::vector<scooterInfo>& scooters);

void printstatistics(std::ostream& out, const Statistics& statistic);
