#include "scooter.hpp"

states defineStats(const scooterInfo& s)
{
    if (s.hasFault){
        return states::SERVICE_REQUIRED;
    }
    if (s.mileage >= max_mileage){
        return states::SERVICE_REQUIRED;
    }
    if (s.charge < min_charge){
        return states::CHARGE_REQUIRED;
    }
    return states::READY;
}

bool readFile(std::ifstream& in, scooterInfo& s)
{
    int fault = 0;
    if (!(in >> s.id >> s.model >> s.charge >> s.mileage >> fault)){
        return false;
    }
    s.hasFault = (fault != 0);
    s.state = defineStats(s);
    return true;
}

void writeFile(std::ofstream& out, const scooterInfo& s)
{
    out << s.id << " " << s.model << " " << s.charge << " " << s.mileage << " " << (s.hasFault ? 1 : 0) << "\n";
}

std::string stateToString(states state)
{
    switch(state)
    {
        case states::READY: return "READY";
        case states::CHARGE_REQUIRED: return "CHARGE_REQUIRED";
        case states::SERVICE_REQUIRED: return "SERVICE_REQUIRED";
    }
}
std::string stateToFilename(states state)
{
    switch(state)
    {
        case states::READY: return "ready.txt";
        case states::CHARGE_REQUIRED: return "charge_required.txt";
        case states::SERVICE_REQUIRED: return "service_required.txt";
    }
}
