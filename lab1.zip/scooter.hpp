#pragma once
#include <string>
#include <fstream>

inline constexpr int min_charge = 30;
inline constexpr double max_mileage = 1500.0;

enum class states
{
    READY, CHARGE_REQUIRED, SERVICE_REQUIRED
};

struct scooterInfo
{
    std::string id;
    std::string model;
    int charge;
    double mileage;
    bool hasFault;
    states state;
};

states defineStats(const scooterInfo& s);

bool readFile(std::ifstream& in, scooterInfo& s);

void writeFile(std::ofstream& out, const scooterInfo& s);

std::string stateToString(states state);

std::string stateToFilename(states state);
