#include <iostream>
#include <string>
#include <vector>
#include <fstream>

#include "scooter.hpp"
#include "statistics.hpp"

namespace
{
    const std::string inputFile = "scooters.txt";
}

int main()
{
    std::ifstream input(inputFile);
    if (!input.is_open()){
        std::cerr << "file open failure \n";
        return 1;
    }

    std::ofstream readyOut(stateToFilename(states::READY));
    std::ofstream chargeOut(stateToFilename(states::CHARGE_REQUIRED));
    std::ofstream serviceOut(stateToFilename(states::SERVICE_REQUIRED));

    if (!readyOut.is_open() || !chargeOut.is_open() || !serviceOut.is_open()){
        std::cerr << "cannot create output file\n";
        return 1;
    }

    std::vector<scooterInfo> allScooters;
    scooterInfo s;

    while (readFile(input, s)){
        switch(s.state){
            case states::READY:
                writeFile(readyOut, s); break;
            case states::CHARGE_REQUIRED:
                writeFile(chargeOut, s); break;
            case states::SERVICE_REQUIRED:
                writeFile(serviceOut, s); break;
        }
        allScooters.push_back(s);
    }

    Statistics statistic = calculateStatistics(allScooters);
    printstatistics(std::cout, statistic);
    return 0;
}
