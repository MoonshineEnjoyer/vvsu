#include "statistics.hpp"
#include <ostream>
#include <iomanip>

Statistics calculateStatistics(const std::vector<scooterInfo>& scooters)
{
    Statistics statistic{};
    statistic.totalScooters = static_cast<int>(scooters.size());

    if (scooters.empty()){
        return statistic;
    }

    long long chargeSum = 0;
    for (const auto& s : scooters)
    {
        switch(s.state)
        {
            case states::READY: ++statistic.readyCount; break;
            case states::CHARGE_REQUIRED: ++statistic.chargeRequiredCount; break;
            case states::SERVICE_REQUIRED: ++statistic.serviceRequiredCount; break;
        }
    chargeSum += s.charge;
    }

    statistic.readyPercent = 100.0 * statistic.readyCount / statistic.totalScooters;
    statistic.averageCharge = static_cast<double>(chargeSum) / statistic.totalScooters;
    return statistic;
}

void printstatistics(std::ostream& out, const Statistics& statistic) {
    out << "STATISTICS\n";
    out << "Total scooters:            " << statistic.totalScooters << '\n';
    out << "Ready:                     " << statistic.readyCount << '\n';
    out << "Charge required:           " << statistic.chargeRequiredCount << '\n';
    out << "Service required:          " << statistic.serviceRequiredCount << '\n';
    out << std::fixed << std::setprecision(1);
    out << "Ready percent:             " << statistic.readyPercent << " %\n";
    out << "Average charge level:      " << statistic.averageCharge << " %\n";
}
